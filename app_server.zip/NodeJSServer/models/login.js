var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var loginSchema = new Schema({
fullname: String,
email: String,
password: String
});

module.exports=mongoose.model('login',loginSchema);
