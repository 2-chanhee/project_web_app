var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var Book = require('./models/book');
var Login = require('./models/login');

mongoose.connect('mongodb://13.125.246.86:27017/Storage')

var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var server = app.listen(80,function() {
    console.log("Express server has started on port 80");
})

app.locals.pretty = true;


app.get('/get-data', function(req, res) {
  Book.find(function(err, books){
        if(err) return res.status(500).send({error: 'database failure'});
        res.send(books);
    })
});
app.get('/getLgndata', function(req, res) {
  Login.find(function(err, logins) {
	if(err) return res.status(500).send({error: 'database failure'});
	res.send(logins);
    })
});
app.post('/insert', function(req, res,next){
    var newBook = new Book();
    newBook.category = req.body.category;
    newBook.title = req.body.title;
    newBook.content = req.body.content;
    newBook.price = req.body.price;
    newBook.imgurl = req.body.imgurl;
    console.log("\n\n post req.body.title="+req.body.title);
    newBook.save(function(err){
        if(err){
            console.error(err);
            res.json({result: 0});
            return;
        }
        res.send("Succes Insertion");
    });
});
app.post('/Lgninsert', function(req, res, next) {
    var newLogin = new Login();
    newLogin.fullname = req.body.fullname;
    newLogin.email = req.body.email;
    newLogin.password = req.body.password;
    console.log("\n\n post req.body.fullname="+req.body.email);
    newLogin.save(function(err){
	if(err){
	    console.error(err);
	    res.json({result: 0});
	    return;
	}
	res.send("Succes Login Insertion");
     });
});

app.post('/delete', function(req, res, next){
    console.log("\n\n delete req="+req);
    Book.remove({ _id: req.body.id }, function(err, output){
        if(err) return res.status(500).json({ error: "database failure" });
        //res.status(204).end();
        //res.json({ message: “book deleted” });
        res.send("Succes Deletion");
    })
});

module.exports = app;
